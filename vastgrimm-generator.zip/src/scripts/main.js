import { generateCharacter } from './generator.js';
import { displayCharacter, showError } from './renderer.js';

function initTheme() {
    const saved = localStorage.getItem('theme');
    if (saved) document.documentElement.setAttribute('data-theme', saved);
    const btn = document.getElementById('btn-theme');
    if (btn) btn.textContent = (saved === 'light') ? '🌑 Dark' : '☀️ Light';
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') ?? 'dark';
    const next = current === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    document.getElementById('btn-theme').textContent = next === 'light' ? '🌑 Dark' : '☀️ Light';
}

initTheme();

async function init() {
    const actionBar = document.getElementById('action-bar');
    actionBar.classList.remove('hidden');

    document.getElementById('btn-theme')?.addEventListener('click', toggleTheme);
    document.getElementById('btn-rigenera').addEventListener('click', genera);
    document.getElementById('btn-stampa').addEventListener('click', () => window.print());

    genera();

    async function genera() {
        try {
            const personaggio = await generateCharacter('vast-grimm');
            displayCharacter(personaggio);
        } catch (err) {
            showError(err.message);
            console.error(err);
        }
    }
}

init().catch(console.error);